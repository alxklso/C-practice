// FINAL VERSION
#include <stdio.h>

// masks 
#define MASK64 0x0000000000000001 // 64-bit 1, for int_multiply
#define MASK8 0xFF // for extracting 8-bit exponent, for float_multiply
#define EXPSHIFT 23 // for shifting 23 bits to get to exponent, for float_multiply 
#define MASK23 0x7FFFFF // for extracting 23-bit mantissa, for float_multiply
#define LEADING1 1 // for adding leading 1, for float_multiply
#define MASK24 24 // for renormalization, for float_multiply
#define SIGNSHIFT 31 // for getting the sign, for float_multiply


// SECTION 1 - create a function that prints bits for num x 
void print_bits(int x) {
    // iterate i from the index of the leftmost bit (in this case 31)
    // down to 0 in the rightmost bit 
    for (int i = (sizeof(int)*8)-1; i >= 0; i--) {

        // determine value of ith bit of x by shifting 
        // x to the right by i and bitwise-AND'ing with 1
        if ((x>>i)&1)
            printf("1");
        else 
            printf("0");
    }
    printf("\n");
}


// SECTION 2 - write a function that takes two 32-bit signed integers, x and y, as 
// parameters and returns a 64-bit signed integer (long)
long int_multiply(int x, int y) { 
    // copy x and y into signed 64-bit long int variables
    signed long lx = x;
    signed long ly = y; 

    // declare 64-bit signed int variable for result, initialize to 0
    signed long result = 0;

    // loop that iterates over bits of ly going from right to left
    // each time, use a mask to determine value of current bit, if current 
    // bit is 1, add lx to result
    // shift lx left one bit
    for (int i = 0; i <= (sizeof(ly)*8); i++) {
        
        if ((MASK64&ly>>i) == 1) { // use mask on number
            result +=lx;
            lx = lx<<1; // bit shift lx left by 1
        }
        else {
            lx = lx<<1; // bit shift lx left by 1
        }
    }
    return result;
}

// SECTION 3 - write a function float_multiply that takes two 32-bit floats a and b
// and returns a 32-bit float resulting from multiplying a and b
float float_multiply(float a, float b) {

    // copy a and b into 32-bit unsigned integer vals
    // cast address of a and b to unsigned int *, then dereference
    unsigned int val_a = *((unsigned int *) &a);
    unsigned int val_b = *((unsigned int *) &b);

    // if either value is 0.0, product is 0.0
    if (val_a == 0.0 || val_b == 0.0)
        return 0.0;

    // else multiply the numbers
    else {
        // extract exponents - shifts bits to the right by 23, extract rightmost 8 bits
        unsigned int val_a_exp = (val_a >> EXPSHIFT) & MASK8; 
        unsigned int val_b_exp = (val_b >> EXPSHIFT) & MASK8;

        // extract mantissas - no shifting needed, extract rightmost 23 bits
        unsigned int val_a_mantissa = val_a & MASK23;
        unsigned int val_b_mantissa = val_b & MASK23;

        // compute exponent of result, sum of each minus one bias 
        unsigned int aggr_exp = ((val_a_exp+val_b_exp)-127);


        // compute manitssa of result

        // insert leading 1 into each mantissa val - put a 1 at bit position 23
        unsigned int leading_a_mantissa = val_a_mantissa | (LEADING1 << EXPSHIFT);
        unsigned int leading_b_mantissa = val_b_mantissa | (LEADING1 << EXPSHIFT);

        // multiply mantissas and store result in 64-bit long
        unsigned long mantissa_product = int_multiply(leading_a_mantissa, leading_b_mantissa);

        // shift result from previous step right by 23 bits
        mantissa_product = (mantissa_product>>EXPSHIFT);

        // if bit 24 of mantissa_product is 1, renormalize by shifting right by 1 bit 
        // and incrementing aggr_exp
        if ((0x1 << MASK24) & mantissa_product) {
            mantissa_product = (mantissa_product >> LEADING1);
            aggr_exp ++;
        }

        // copy value of 64-bit mantissa variable into 32-bit unsigned int variable
        unsigned int final_mantissa = mantissa_product;


        // extract sign bits from val_a and val_b
        unsigned int val_a_sign = (val_a >> SIGNSHIFT) & LEADING1;
        unsigned int val_b_sign = (val_b >> SIGNSHIFT) & LEADING1;

        // compute sign of product using XOR (^)
        // if XOR = 1, sign of product is 1 (negative), else it is 0 (positive)
        int product_sign = (val_a_sign^val_b_sign);

        // construct result of multiplication by inserting into 32-bit unsigned int variable 
        // sign bit, exponent bits, and mantissa bits (mask out implicit 1 in spot 24)
        unsigned int result = 0; // initialize to 0
        unsigned int m = mantissa_product; // copy of mantissa 
        m = (m& ~(1 << 23));

        result = result | ((mantissa_product & LEADING1) << SIGNSHIFT); // add sign
        result = result | ((aggr_exp & MASK8) << EXPSHIFT); // add exponent
        result = result | (m&MASK23); // add mantissa

        float f = *((float*) &result);
        return f; // return float product
    }
}