// FINAL VERSION
// include prototypes of functions
void print_bits(int x);                            // SECTION 1
long int_multiply(int x, int y);                   // SECTION 2
float float_multiply(float a, float b);            // SECTION 3