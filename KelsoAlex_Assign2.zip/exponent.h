// FINAL VERSION
int exponent(int x, int y, int n);